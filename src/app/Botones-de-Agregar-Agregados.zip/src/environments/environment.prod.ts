export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyDl0V7bWbCqFRo2Z4RiS8xXG6MukZlRoyo",
    authDomain: "mecanica-dental.firebaseapp.com",
    databaseURL: "https://mecanica-dental.firebaseio.com",
    projectId: "mecanica-dental",
    storageBucket: "mecanica-dental.appspot.com",
    messagingSenderId: "426798082187",
    appId: "1:426798082187:web:e53599b758c39543498c8e"
  }
};
